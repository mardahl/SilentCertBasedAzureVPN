﻿#This script is part of an automated solution to install Azure VPN Client as an Always On VPN. 
#Don't execute directly
#This part of the solution is designed to be run in SYSTEM context

[CmdletBinding()]
Param(
    [Parameter(Mandatory)]
    $sourceXMLAndPath,
    [Parameter(Mandatory)]
    $destination,
    [Parameter(Mandatory)]
    $UserSID
)

#region Execute
Write-Verbose "Configuring Always On settings" -Verbose

#set location to script dir
function Get-ScriptDirectory {
    if ($psise) {
        Split-Path $psise.CurrentFile.FullPath
    }
    else {
        $global:PSScriptRoot
    }
}
$ScriptDir = Get-ScriptDirectory
Set-Location $ScriptDir

#Generate path variable for PBK file
$pbkPath = Join-Path -Path $destination -ChildPath "rasphone.pbk"

Start-Sleep -Seconds 10

#Getting Phonebook file
$pbkData = (Get-Content -Path $pbkPath) -split ('\n')

#Getting VPN Profile XML
$xmlData = [xml](Get-Content $sourceXMLAndPath)

#Defining registry path to save Always On Profile in
$RasManRegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\RasMan\Config"

#Gathering data needed for the registry entries
$AutoTriggerProfilePhonebookPath = $pbkPath
$AutoTriggerProfileEntryName = $xmlData.azvpnprofile.name

#Getting correct dialup entry Guid from pbk
$foundProfile = $false
foreach($line in $pbkData) {

    #First. searching for correct profile entry in pbk (needed for those time when there might be multiple profiles)
    if($line -eq "[$AutoTriggerProfileEntryName]"){
        $foundProfile = $true
        continue
    }

    #Second. getting Guid from the correct entry (I gave up on regex)
    if(($foundProfile -eq $true) -and ($line -like "Guid=*")){
        $GUID = ($line -split ('='))[1]
        $AutoTriggerProfileGUID = [byte[]] -split ($GUID -replace '..', '0x$& ')
        break
    }

}

#Checking AutoTriggerDisabledProfilesList
if(Test-Path -Path $RasManRegPath) {

    if((Get-ItemProperty -Path $RasManRegPath | Select-Object AutoTriggerDisabledProfilesList -ExpandProperty AutoTriggerDisabledProfilesList -ErrorAction SilentlyContinue) -icontains $AutoTriggerProfileEntryName){
        Write-Verbose "VPN Profile found in AutoTriggerDisabledProfilesList! - Removing" -Verbose
        $removeDisabledList = $true
    }

} else {

    $regpath = $RasManRegPath -replace '\config',''
    New-Item -Path $regpath -Name 'Config' -Force

}

Write-Verbose "Updating registry" -Verbose
#Adding found values to the Registry (Requires admin or system permissions)
try {

    Push-Location $RasManRegPath
    New-ItemProperty -Path . -Name AutoTriggerProfileGUID -PropertyType Binary -Value $AutoTriggerProfileGUID -Force -Confirm:$false -ErrorAction Stop | Out-Null
    New-ItemProperty -Path . -Name AutoTriggerProfilePhonebookPath -PropertyType String -Value $AutoTriggerProfilePhonebookPath -Force -Confirm:$false -ErrorAction Stop | Out-Null
    New-ItemProperty -Path . -Name AutoTriggerProfileEntryName -PropertyType String -Value $AutoTriggerProfileEntryName -Force -Confirm:$false -ErrorAction Stop | Out-Null
    New-ItemProperty -Path . -Name UserSID -PropertyType String -Value $UserSID -Force -Confirm:$false -ErrorAction Stop | Out-Null

    #Removing Always On Profile from disabled list (currently just deletes the registry item, and all values inside it)
    if ($removeDisabledList) {
        Remove-ItemProperty -Path $RasManRegPath -Name AutoTriggerDisabledProfilesList -Force -Confirm:$false -ErrorAction Stop | Out-Null
    }

    Pop-Location

} catch {

    Throw $_

}

#endregion Execute