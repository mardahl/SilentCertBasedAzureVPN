﻿<#
.SYNOPSIS
    Removes VPN profile deployed by the accompanying install script
#>

#Requires -Version 5

#region Declarations

#Log location
$LogPath = Join-Path -Path $env:TEMP -ChildPath "PSScript_LOG_Remove-AzureVPNProfileAsAlwaysOn.txt"

#set location to script dir
function Get-ScriptDirectory {
    if ($psise) {
        Split-Path $psise.CurrentFile.FullPath
    }
    else {
        $global:PSScriptRoot
    }
}
$ScriptDir = Get-ScriptDirectory
Set-Location $ScriptDir

#Profile XML (The one exported manually from Azure VPN Client should be placed in the same directory as this script - You get this after importing the downloaded profile manually into the app, and exporting it again.)
#The script will get the first exported profile XML file that is stored with this script. So don't place any other profiles XML files in the script directory. Unless you feel up to modifying this script.
#SPACES IN THE FILENAME ARE FORBIDDEN!
try {
    $ProfileXML = Get-ChildItem -Path . | Where-Object {$_.Name -ilike "*.xml"} -ErrorAction Stop | Select-Object VersionInfo, Name -First 1
    $sourceXMLAndPath = $ProfileXML.VersionInfo.FileName
} Catch {
    Throw "No valid Azure VPN Client configuration export file found in script directory!"
    exit 1
}

#endregion Declarations

#region Execute

#Start log
Start-Transcript -Path $LogPath -Force


#Get SID of currently logged in user
try {

    $LoggedInUser = Get-WmiObject -Class Win32_ComputerSystem | select username -ExpandProperty username
    $UserObj = New-Object System.Security.Principal.NTAccount($LoggedInUser)
    $UserSID = [string]$UserObj.Translate([System.Security.Principal.SecurityIdentifier]).Value
    Write-Verbose "Identified $LoggedInUser as the current user of this computer." -Verbose

} Catch {

    Write-Error $_
    Stop-Transcript
    Exit 1

}

#Get UserProfile directory of logged in user
$UserProfilePath = Get-WmiObject win32_userprofile | Where-Object { $_.SID -eq $UserSID } | Select-Object LocalPath -ExpandProperty LocalPath
$destination = join-path $UserProfilePath -ChildPath "AppData\Local\Packages\Microsoft.AzureVpn_8wekyb3d8bbwe\LocalState"

try {
    
    #disconnect any established VPNs
    rasdial /disconnect

    #Delete VPN configuration
    Write-Verbose "Removing VPN Profile" -Verbose
    Remove-Item "$destination\rasphone.pbk" -Force
    Remove-Item "$destination\$($ProfileXML.Name)" -Force



} catch {

    Write-Error $_
    Exit 1

} Finally {

    Stop-Transcript

}

#endregion Execute