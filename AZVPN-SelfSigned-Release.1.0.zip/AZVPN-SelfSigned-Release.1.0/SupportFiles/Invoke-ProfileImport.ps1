#This script is part of an automated solution to install Azure VPN Client as an Always On VPN. 
#Don't execute directly
#This part of the solution is designed to be run in USER context

#MAKE SURE YOU HAVE A SELFSIGNED PFX CERTIFICATE CALLED p2schild.pfx IN THE SAME FOLDER AS THIS SCRIPT!
#MODIFY THE PASSWORD FOR THE FILE IN THE LOWER PART OF THIS SCRIPT!

[CmdletBinding()]
Param(
    [Parameter(Mandatory)]
    $sourceXMLAndPath
)

#region Functions

function Invoke-ImportProfile(){
    #function that validates and copies the Profile XML
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory)]
        $ProfileXMLPath
    )

    $filename = Get-ChildItem $ProfileXMLPath | Select-Object Name -ExpandProperty Name
    azurevpn -i $filename

    #waiting for profile import to complete and end the GUI
    Start-Sleep -Seconds 4
    Stop-Process -Name AzVpnAppx -Force

}

function Get-ScriptDirectory {
    if ($psise) {
        Split-Path $psise.CurrentFile.FullPath
    }
    else {
        $global:PSScriptRoot
    }
}

#endregion Functions

#region Execute

#Start log
Start-Transcript -Path (Join-Path $env:TEMP -ChildPath azvpn_user_import_log.txt)

#set location to script dir
$ScriptDir = Get-ScriptDirectory
Set-Location $ScriptDir

#Importing Self-Signed cert
$password = ConvertTo-SecureString "1234Password" -AsPlainText -Force
Import-PfxCertificate -FilePath .\p2schild.pfx -CertStoreLocation Cert:\CurrentUser\My -Password $password

#Import profile
Write-Verbose "Importing Profile" -Verbose
Invoke-ImportProfile -ProfileXMLPath $sourceXMLAndPath

Stop-Transcript
#endregion Execute