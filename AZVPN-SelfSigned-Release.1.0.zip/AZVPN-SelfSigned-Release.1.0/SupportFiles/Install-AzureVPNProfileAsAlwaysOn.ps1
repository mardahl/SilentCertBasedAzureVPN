﻿<#
.SYNOPSIS
    Automatically imports Point-to-site VPN profile into the Appx version of the Azure PVN Client (needs to be installed for the user via the Microsoft Store)
    The script will also configure the VPN profile to automatically connect at logon.
.DESCRIPTION
    (c) Michael Mardahl <github.com/mardahl>.
    Script provided as-is without any warranty of any kind. Use it freely at your own risks.
    MIT License, feel free to distribute and use as you like, leave author information.
.INPUTS
    None
.OUTPUTS
    None
.NOTES
    Version:        1.0
    Author:         Michael Mardahl
    Twitter:        @michael_mardahl
    Blogging on:    www.msendpointmgr.com
    Creation Date:  08 May 2020
    Purpose/Change: Initial script development
.EXAMPLE
    Execute this script in SYSTEM context or as a local administrator
    .\Install-AzureVPNProfileAsAlwaysOn.ps1
    Executing user must have administrative access and execute the script in an elevated PS Session.
#>

#Requires -Version 5
#Requires -RunAsAdministrator

#region Declarations

#Log location
$LogPath = Join-Path -Path $env:TEMP -ChildPath "PSScript_LOG_Install-AzureVPNProfileAsAlwaysOn.txt"
#Start log
Start-Transcript -Path $LogPath -Force

#set location to script dir
function Get-ScriptDirectory {
    if ($psise) {
        Split-Path $psise.CurrentFile.FullPath
    }
    else {
        $global:PSScriptRoot
    }
}
$ScriptDir = Get-ScriptDirectory
Set-Location $ScriptDir

#Profile XML (The one you exported from the vpn client when you did a manual install)
#The script will get the first XML file that is stored with this script. So don't place any other XML files in the script directory. Unless you feel up to modifying this script.
#NB: NO SPACES ALLOWED IN THE profile xml FILENAME!
try {
    $ProfileXML = Get-ChildItem -Path . | Where-Object {$_.Name -ilike "*.xml"} -ErrorAction Stop | Select-Object VersionInfo, Name -First 1
    $sourceXMLAndPath = $ProfileXML.VersionInfo.FileName
} Catch {
    Throw "No valid Azure VPN Client configuration export file found in script directory!"
    exit 1
}

#endregion Declarations

#region Functions

. .\Invoke-ExecuteAsLoggedOnUser.ps1

function Invoke-CopyProfile(){
    #function that validates and copies the Profile XML
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory)]
        $source,
        [Parameter(Mandatory)]
        $destination
    )

    Try {

        Test-Path $source -ErrorAction Stop | Out-Null
        Test-Path $destination -ErrorAction Stop | Out-Null
        Copy-Item $source -Destination $destination -Force -Verbose -ErrorAction Stop

    } Catch {

        Throw "Copy operation failed! VPN Software might not be installed or the source XML could not be found!"

    }
}

#endregion Functions

#region Execute



#Importing Self-Signed cert

$password = ConvertTo-SecureString "1234" -AsPlainText -Force
Import-PfxCertificate -FilePath .\p2schild.pfx -CertStoreLocation Cert:\LocalMachine\My -Password $password

#Get SID of currently logged in user
try {

    $LoggedInUser = Get-WmiObject -Class Win32_ComputerSystem | select username -ExpandProperty username
    $UserObj = New-Object System.Security.Principal.NTAccount($LoggedInUser)
    $UserSID = [string]$UserObj.Translate([System.Security.Principal.SecurityIdentifier]).Value
    Write-Verbose "Identified $LoggedInUser as the current user of this computer." -Verbose

} Catch {

    Write-Error $_
    Stop-Transcript
    Exit 1

}

#Get UserProfile directory of logged in user
$UserProfilePath = Get-WmiObject win32_userprofile | Where-Object { $_.SID -eq $UserSID } | Select-Object LocalPath -ExpandProperty LocalPath
$destination = join-path $UserProfilePath -ChildPath "AppData\Local\Packages\Microsoft.AzureVpn_8wekyb3d8bbwe\LocalState"

try {

    #Copy profile to client software
    Write-Verbose "Copying profile to Azure VPN Client in User Profile." -Verbose
    Invoke-CopyProfile -source $sourceXMLAndPath -destination $destination

    #Executing in logged in users context
    Write-verbose "Importing VPN Profile as $LoggedInUser." -Verbose
    $userCommand = '-file "{0}" -sourceXMLAndPath "{1}"' -f $(Resolve-Path .\Invoke-ProfileImport.ps1).Path,$sourceXMLAndPath
    $impersonateResult = Invoke-executeAsLoggedOnUser -Command $userCommand -Hidden $true
    Start-Sleep -Seconds 3 #Needed wait time, for AZ VPN to execute and create a PBK file.
    Write-Verbose "$impersonateResult" -Verbose

    #Adding always On information to registry
    .\Invoke-AlwaysOnConfig.ps1 -sourceXMLAndPath $sourceXMLAndPath -destination $destination -UserSID $UserSID #As SYSTEM
    Write-Verbose "Always On configuration completed for user $LoggedInUser" -Verbose

} catch {

    Write-Error $_
    Exit 1

} Finally {

    Stop-Transcript

}

#endregion Execute