#This script is part of an automated solution to install Azure VPN Client as an Always On VPN. 
#Don't execute directly
#This part of the solution is designed to be run in USER context

#YOU NEED TO MODIFY THE PART THAT LOOKS FOR THE USER CERTIFIKATE IN THE STORE!
#YOU MUST HAVE PREDEPLOYED A "CLIENT AUTHENTICATION" CERTIFICATE TO THE USER!

[CmdletBinding()]
Param(
    [Parameter(Mandatory)]
    $sourceXMLAndPath
)

#region Functions

function Invoke-ImportProfile(){
    #function that validates and copies the Profile XML
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory)]
        $ProfileXML
    )

    azurevpn -i $ProfileXML

    #waiting for profile import to complete and end the GUI
    Start-Sleep -Seconds 4
    Stop-Process -Name AzVpnAppx -Force

}

function Get-ScriptDirectory {
    if ($psise) {
        Split-Path $psise.CurrentFile.FullPath
    }
    else {
        $global:PSScriptRoot
    }
}

#endregion Functions

#region Execute

#Start log
Start-Transcript -Path (Join-Path $env:TEMP -ChildPath azvpn_user_import_log.txt)

#set location to script dir
$ScriptDir = Get-ScriptDirectory
Set-Location $ScriptDir

#Fixing certificate hash info required in the profile xml
try {
    Write-Verbose "Verifying existence of required certificate for Azure P2S VPN..." -Verbose
    $issuer = 'IssuingCA'
    $templateName = 'Azure P2S'
    $certs = Get-ChildItem -Path cert:\currentuser\my | Where-Object Issuer -like "*$issuer*" -ErrorAction Stop
    $cert = $certs | Where-Object{ $_.Extensions | Where-Object{ ($_.Oid.Value -eq '1.3.6.1.4.1.311.21.7') -and ($_.Format(0) -like "*$templateName*") }} -ErrorAction Stop
    if(!$cert){throw}
    Write-Verbose "Required certificate found!" -Verbose
} catch {
    Write-Error "Missing certificate issued with the `"$templateName`" certificate template from the issuer `"$issuer!`""
    exit 1
}

#Build path to the users copy of the profile XML file
$XMLfilename = Get-ChildItem $sourceXMLAndPath | Select-Object Name -ExpandProperty Name
$userXMLAndPath = Join-Path $env:LOCALAPPDATA "\Packages\Microsoft.AzureVpn_8wekyb3d8bbwe\LocalState\$XMLfilename"

#add cert hash to config profil xml
[xml]$tempProfileXML = Get-Content $userXMLAndPath
$tempProfileXML.azvpnprofile.clientauth.cert.hash = $cert.Thumbprint
$tempProfileXML.save("$userXMLAndPath")


#Import the modified profile
Write-Verbose "Importing Profile" -Verbose
Invoke-ImportProfile -ProfileXML $XMLfilename

Stop-Transcript
#endregion Execute